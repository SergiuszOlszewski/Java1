package com.company;

public class Main
{
    public static void main(String[] args)
    {
        int a=1;
        int b=19;
        if((a>12&&a<20)&&(b<13||b>19))
            System.out.println("teen");
        if((b>12&&b<20)&&(a<13||a>19))
            System.out.println("teen");
    }
}
