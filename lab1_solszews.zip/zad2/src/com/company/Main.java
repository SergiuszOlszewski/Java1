package com.company;

public class Main {

    public static void main(String[] args) {
        int a = 6;
        int b = 12;
        int c = 13;
        int suma = 0;
        if (a != 13)
        {
            suma += a;
            if (b != 13)
            {
                suma += b;
                if (c != 13)
                    suma += c;
            }
        }
        System.out.println(suma);
    }
}