package com.company;

public class Main
{

    public static void main(String[] args)
    {
        int[] array={2,4,1,2,3,7,4,1,2,6,3};
        int last=0;
        for(int element : array)
        {
            if(element==last+1)
                last++;
            else
                last=0;
            if(last==3)
            {
                System.out.println("true");
                break;
            }
        }
    }
}
